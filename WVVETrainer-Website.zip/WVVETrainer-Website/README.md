# WVVETrainer Website

A responsive static website for the WVVETrainer Roblox roleplay community.

## Files
- `index.html` — all page content and sections
- `style.css` — black, white and gold responsive styling
- `script.js` — mobile navigation, active section and current year

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new **public** repository named `wvvettrainer-site` (or another name you prefer).
3. Upload `index.html`, `style.css`, and `script.js` to the repository's top level.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then save.
7. Wait a few minutes. GitHub will show the public website address in the Pages area.

The free address will look like `https://YOUR-USERNAME.github.io/wvvettrainer-site/`.
A custom `.com` domain generally costs money, so this uses the free GitHub Pages address.

## Before sharing
- Replace the starter department descriptions with your real group information.
- Add confirmed staff names and roles in the Leadership section.
- Update the rules to match your official Roblox and Discord community rules.
- The Discord invite is currently set to `https://discord.gg/6uerTPNUFz`.

This is a static front-end site. It does not collect or store applications. Use your Discord server for applications and member support.
